<?php
session_start();

// Проверяем, был ли уже выполнен вход
if(isset($_SESSION['user_id'])) {
    // В зависимости от текущей страницы, перенаправляем пользователя
    if(basename($_SERVER['PHP_SELF']) == 'index.php') {
        header("Location: index7.php");
    } else {
        header("Location: index.php");
    }
    exit();
}

// Проверяем, была ли отправлена форма для входа
if(isset($_POST['login'])) {
    // Проверка учетных данных
    if($_POST['username'] === 'ваш_логин' && $_POST['password'] === 'ваш_пароль') {
        $_SESSION['user_id'] = 1; // Установка переменной сессии
        // В зависимости от текущей страницы, перенаправляем пользователя
        if(basename($_SERVER['PHP_SELF']) == 'index.php') {
            header("Location: index7.php");
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        $error = "Неверное имя пользователя или пароль!";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <title>Вход</title>
</head>
<body>
    <h2>Вход</h2>
    <form method="post">
        <input type="text" name="username" placeholder="Имя пользователя" required><br>
        <input type="password" name="password" placeholder="Пароль" required><br>
        <button type="submit" name="login">Войти</button>
    </form>
    <?php if(isset($error)) { echo $error; } ?>
</body>
</html>
